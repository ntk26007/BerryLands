package stage1;

import ui.Marco;

public class Main {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.iniciarJuego();

      
    }
}



